﻿namespace BankCharges
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double baseFee = 10.00;
            double lessThan20 = 00.10;
            double twentyTo39 = 00.08;
            double fortyTo59 = 00.06;
            double sixtyPlus = 00.04;
            //again, defining my variables. just doing this so i dont have to type 00.10, 00.08, etc extra.
            //also, using doubles for the cent calculations. i dont want to figure any other thing out today

            Console.WriteLine("Welcome, valued (insert bank here) customer! How many checks did you write this month?");
            int checksWritten = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Thank you! Processing your monthly check fee and bill....");

            double checkFee = 0;
            if (checksWritten < 20)
            {
                checkFee = checksWritten * lessThan20;
            }
            else if (checksWritten <= 39)
            {
                checkFee = checksWritten * twentyTo39;
            }
            else if (checksWritten <= 59)
            {
                checkFee = checksWritten * fortyTo59;
            }
            else checkFee = checksWritten * sixtyPlus;
            double totalBill = baseFee + checkFee;
            Console.WriteLine("Your check fee for the month was $" + checkFee + ".");
            Console.WriteLine("Your total bill for the month was $" + totalBill + ".");
        }
    }
}