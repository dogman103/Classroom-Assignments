﻿namespace SpeedOfSound
{
    internal class Program
    {
        static void Main(string[] args)
        {
            decimal airSpeed = 1100;
            decimal waterSpeed = 4900;
            decimal steelSpeed = 16400;
            // defining the main variables for the speed of sound through the mediums
            //also using decimals so we can have half of a specified distance

            Console.WriteLine("Please enter the medium (air, water, or steel) that the sound wave will be traveling through.");
            //gotta make the computer sound friendly + willing to help! i hate rude  computers

            string userMedium = Console.ReadLine();
            Console.WriteLine("Thank you!");
            Console.WriteLine("Next, please enter the distance that the sound wave will be traveling in feet.");
            decimal userDistance = Convert.ToDecimal(Console.ReadLine());
            //thx gyllenwater for the help figuring out the conversion! big help out here

            Console.WriteLine("Thank you! Processing....");

            decimal totalTime;

            if (userMedium.ToLower() == "air")
            {
                totalTime = userDistance / airSpeed;
            }
            else if (userMedium.ToLower() == "water")
            {
                totalTime = userDistance / waterSpeed;
            }
            else if (userMedium.ToLower() == "steel")
            {
                totalTime = userDistance / steelSpeed;
            }
            else totalTime = 0;
            //simple little if / else if section to determine the medium and perform the calculations

            Console.WriteLine("The time it takes for the sound to travel " + userDistance + " feet through " + userMedium + " is " + totalTime + " seconds.");



        }
    }
}