﻿namespace AudioBooks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double packageA = 9.95;
            double packageB = 13.95;
            double packageC = 19.95;
            //again, just defining the basic variables that the final calculations will depend on
            //at the top for my own sanity

            Console.WriteLine("Please enter the letter of the plan (A, B, or C) which you have purchased.");
            string userPlan = Console.ReadLine();
            Console.WriteLine("Thank you! Next, please enter the number of audiobooks that you listened to this month.");
            double userBookNumber = Convert.ToDouble(Console.ReadLine());
            //converting the user book number to a double, which will let us do the number #crunching

            Console.WriteLine("Thank you! Processing...");
            double userCost;
            if (userPlan.ToLower() == "a")
            {
                if (userBookNumber <= 10)
                {
                    userCost = packageA;
                }
                else
                // thanks again G dawg for the help telling me to not use else if when there is no else if needed
                {
                    userCost = ((userBookNumber - 10) * 2.00) + packageA;
                }
            }
            else if (userPlan.ToLower() == "b")
            {
                if (userBookNumber <= 20)
                {
                    userCost = packageB;
                }
                else
                {
                    userCost = ((userBookNumber - 20) * 1.00) + packageB;
                }
            }
            else if (userPlan.ToLower() == "c")
            {
                userCost = packageC;
            }
            else 
            {
                userCost = 0;
                Console.WriteLine("Error! Please restart the program."); 
            }

            //REMEMBER YOUR CURLY BRACES!!!!!

            if (userCost >= 9.95)
            {
                Console.WriteLine("Your total monthy bill is $" + userCost + ".");
            }
            else Console.WriteLine("Error! Please restart the program.");
        }
    }
}